package main_package;

public class Validation {
    boolean isNegative(int input)
    {
        return input < 0 ;
    }
    boolean isNotOneOrTwo(int input)
    {
        return !(input == 1 || input == 2) ;
    }
}
